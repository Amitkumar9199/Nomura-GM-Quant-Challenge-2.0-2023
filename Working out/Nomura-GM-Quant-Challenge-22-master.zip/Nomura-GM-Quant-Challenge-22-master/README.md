# Nomura-GM-Quant-Challenge-22
